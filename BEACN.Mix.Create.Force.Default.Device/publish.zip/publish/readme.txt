to install, run install.bat as administrator
to uninstall, run uninstall.bat as administrator